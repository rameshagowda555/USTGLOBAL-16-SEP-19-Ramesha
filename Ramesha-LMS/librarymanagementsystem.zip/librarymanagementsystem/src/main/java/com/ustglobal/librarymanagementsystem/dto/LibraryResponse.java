package com.ustglobal.librarymanagementsystem.dto;

import lombok.Data;

@Data
public class LibraryResponse {
	private int statusCode;
	private String message;
	private String description;
}
