package com.ustglobal.librarymanagementsystem.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.ustglobal.librarymanagementsystem.dto.AdminBean;
import com.ustglobal.librarymanagementsystem.dto.LibrarianBean;
import com.ustglobal.librarymanagementsystem.dto.StudentBean;
@Repository
public class AdminDAOImpl implements AdminDAO {

	@PersistenceUnit
	private EntityManagerFactory factory;
	@Override
	public AdminBean adminLogin(int adminId, String adminPassword) {
		String jpql = "from AdminBean where adminId=:id and adminPassword=:pass";
		EntityManager manager = factory.createEntityManager();
		TypedQuery<AdminBean>query = manager.createQuery(jpql,AdminBean.class);
		query.setParameter("id", adminId);
		query.setParameter("pass", adminPassword);
		try {
			AdminBean bean = query.getSingleResult();
			return bean;
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public boolean addStudent(StudentBean bean) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		try {
			manager.persist(bean);
			transaction.commit();
			return true;
		}catch(Exception e) {
			e.printStackTrace();
			transaction.rollback();
			return false;
		}
	}

	@Override
	public boolean addLibrarian(LibrarianBean bean) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		try {
			manager.persist(bean);
			transaction.commit();
			return true;
		}catch(Exception e) {
			e.printStackTrace();
			transaction.rollback();
			return false;
		}
	}

	@Override
	public boolean removeStudent(int studentId) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		StudentBean bean = manager.find(StudentBean.class, studentId);
		if(bean!=null) {
			manager.remove(bean);
			transaction.commit();
			return true;
		}else {
			return false;
		}
	}

	@Override
	public boolean removeLibrarian(int librarianId) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		LibrarianBean bean = manager.find(LibrarianBean.class,librarianId);
		if(bean!=null) {
			manager.remove(bean);
			transaction.commit();
			return true;
		}else {
			return false;
		}
	}

	@Override
	public StudentBean searchStudent(int studentId) {
		EntityManager manager = factory.createEntityManager();
		StudentBean bean = manager.find(StudentBean.class, studentId);
		return bean;
	}

	@Override
	public List<StudentBean> searchAllStudent() {
		String jpql = "from StudentBean";
		EntityManager manager = factory.createEntityManager();
		TypedQuery<StudentBean> query = manager.createQuery(jpql,StudentBean.class);
		List<StudentBean> bean = query.getResultList();
		return bean;
	}

	@Override
	public boolean updateStudent(StudentBean bean) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		StudentBean studentBean = manager.find(StudentBean.class, bean.getStudentId());
		studentBean.setStudentName(bean.getStudentName());
		studentBean.setStudentGender(bean.getStudentDoj());
		studentBean.setStudentPassword(bean.getStudentPassword());
		studentBean.setStudentMobileNo(bean.getStudentMobileNo());
		studentBean.setStudentId(bean.getStudentId());
		studentBean.setYearOfStudying(bean.getYearOfStudying());
		transaction.commit();
		return true;
	}

	@Override
	public boolean updateLibrarian(LibrarianBean bean) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		LibrarianBean librarianBean = manager.find(LibrarianBean.class, bean.getLibrarianId());
		librarianBean.setLibrarianName(bean.getLibrarianName());
		librarianBean.setLibrarianPassword(bean.getLibrarianPassword());
		librarianBean.setLibrarianGender(bean.getLibrarianGender());
		librarianBean.setLibrarianId(bean.getLibrarianId());
		librarianBean.setLibrarianMobileNo(bean.getLibrarianMobileNo());
		transaction.commit();
		return true;
	}
}
